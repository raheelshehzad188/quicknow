<!-- Newsletter Start -->
<div class="newsletter">
    <div class="container">
        <div class="section-header">
            <h3>Subscribe Our Newsletter</h3>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec viverra at massa sit amet ultricies. Nullam consequat, mauris non interdum cursus
            </p>
        </div>
        <div class="form">
            <input type="email" value="Your email here">
            <button>Submit</button>
        </div>
    </div>
</div>
<!-- Newsletter End -->