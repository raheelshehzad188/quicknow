<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Account Opening</title>
</head> 
<body>
    <p>Hi {{ $name }},</p>

    <p>You recently requested a new password. We've received the request and your password has been changed.</p><br>
    
    <p>Your account type is : user</p><br>
    
    <p>Your new password is : {{$password}}</p><br>
    
    <p>Thanks,</p><br>
    
    <p>DealShop
    </p>
</body>
</html>